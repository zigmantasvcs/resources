<?php
    $dbServer = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbName = "forma2";

    $conn = mysqli_connect($dbServer, $dbUsername, $dbPassword, $dbName);


