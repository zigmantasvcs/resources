<nav>
 <div class="nav-wrapper mycustomcolor">
   <a href="#!" class="brand-logo"><img src="images/logo.png" width="63px" /></a>

   <a href="#" data-activates="sidemenu" class="button-collapse">
     <i class="material-icons">menu</i>
   </a>

   <ul class="right hide-on-med-and-down">
     <li><a href="about.php">Apie</a></li>
     <li><a href="login.php">Prisijungti</a></li>
     <li><a href="register.php">Registruotis</a></li>
   </ul>

   <ul class="side-nav" id="sidemenu">
     <li><a href="about.php">Apie</a></li>
     <li><a href="login.php">Prisijungti</a></li>
     <li><a href="register.php">Registruotis</a></li>
   </ul>
 </div>
</nav>
