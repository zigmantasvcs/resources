<?php
  /**
   *
   */
  interface iOperations
  {
    public function create($object);
    public function read($id);
  }
 ?>
