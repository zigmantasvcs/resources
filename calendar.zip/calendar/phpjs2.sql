-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 2018 m. Kov 19 d. 22:36
-- Server version: 10.1.24-MariaDB
-- PHP Version: 7.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `phpjs2`
--

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_lithuanian_ci NOT NULL,
  `eventdate` datetime NOT NULL,
  `description` varchar(500) COLLATE utf8_lithuanian_ci DEFAULT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_lithuanian_ci;

--
-- Sukurta duomenų kopija lentelei `events`
--

INSERT INTO `events` (`id`, `name`, `eventdate`, `description`, `created`) VALUES
(1, 'labas', '2017-11-23 00:00:00', NULL, '2017-11-24 20:51:44'),
(2, 'sadasd', '2017-11-09 00:00:00', NULL, '2017-11-24 21:04:04'),
(3, 'asd', '2017-11-30 00:00:00', NULL, '2017-11-27 15:33:56'),
(4, 'asd', '2017-11-29 00:00:00', NULL, '2017-11-27 15:34:46'),
(5, 'asd', '2017-11-30 00:00:00', NULL, '2017-11-27 15:38:08'),
(6, 'asd', '2017-11-16 00:00:00', NULL, '2017-11-27 15:41:29'),
(7, 'asd', '2017-11-19 00:00:00', NULL, '2017-11-27 21:13:43'),
(8, 'asd', '2017-11-17 00:00:00', NULL, '2017-11-27 22:42:06'),
(9, 'asd', '0000-00-00 00:00:00', NULL, '2017-11-27 23:39:04'),
(10, 'asd', '2017-11-10 00:00:00', NULL, '2017-11-27 23:53:44'),
(11, 'asd', '2017-11-01 00:00:00', NULL, '2017-11-28 00:33:02'),
(12, 'asd', '2017-11-09 00:00:00', NULL, '2017-11-28 09:24:07'),
(13, 'asd', '2017-11-24 00:00:00', NULL, '2017-11-28 09:27:23'),
(14, 'asd', '2017-11-17 00:00:00', NULL, '2017-11-28 09:27:29'),
(15, '<script>alert(\'aaa\');</script>', '2017-11-17 00:00:00', NULL, '2017-11-28 09:38:36'),
(16, 'asd', '2017-11-10 00:00:00', NULL, '2017-11-28 15:14:25'),
(17, 'asd', '2017-11-10 00:00:00', NULL, '2017-11-28 15:17:52'),
(18, 'asd', '2017-11-10 00:00:00', NULL, '2017-11-28 15:18:05'),
(19, 'asd', '2017-11-09 00:00:00', NULL, '2017-11-28 15:18:34'),
(20, 'asd', '2017-11-10 00:00:00', NULL, '2017-11-28 16:07:11'),
(21, 'adasd', '2017-11-10 00:00:00', NULL, '2017-11-28 16:08:22'),
(22, 'asd', '2017-11-23 00:00:00', NULL, '2017-11-28 17:45:39'),
(23, 'asd', '2017-11-23 00:00:00', NULL, '2017-11-28 17:47:06'),
(24, 'asd', '2017-11-23 00:00:00', NULL, '2017-11-28 18:01:39'),
(25, 'asd', '2017-11-23 00:00:00', NULL, '2017-11-28 18:02:25'),
(26, 'asd', '2017-11-23 00:00:00', NULL, '2017-11-28 18:17:53'),
(27, 'testas', '2017-11-30 00:00:00', NULL, '2017-11-28 18:20:45'),
(28, 'tstas', '2017-11-17 00:00:00', NULL, '2017-11-28 18:22:10'),
(29, 'testas', '2017-11-07 00:00:00', NULL, '2017-11-28 18:34:31'),
(30, 'testas', '2017-11-14 00:00:00', NULL, '2017-11-28 18:35:08'),
(31, 'testas', '2017-11-13 00:00:00', NULL, '2017-11-28 18:55:10'),
(32, 'teras', '2017-11-10 00:00:00', NULL, '2017-11-28 19:17:22'),
(33, 'asdasd', '2017-11-03 00:00:00', NULL, '2017-11-28 19:43:51'),
(34, 'testas', '2017-11-10 00:00:00', NULL, '2017-11-28 19:44:53'),
(35, 'testas', '2017-11-10 00:00:00', NULL, '2017-11-28 19:49:03'),
(36, 'asd', '2017-12-07 00:00:00', NULL, '2017-12-17 22:25:26'),
(37, 'test', '2017-12-29 00:00:00', NULL, '2017-12-17 23:15:57'),
(38, 'testas', '2018-02-08 00:00:00', NULL, '2018-02-21 08:59:29'),
(39, 'aaa', '2018-03-09 00:00:00', NULL, '2018-03-19 23:25:12'),
(40, 'asdasd', '2018-03-01 00:00:00', NULL, '2018-03-19 23:34:25');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(40) COLLATE utf8_lithuanian_ci NOT NULL,
  `surname` varchar(40) COLLATE utf8_lithuanian_ci NOT NULL,
  `birthday` date NOT NULL,
  `username` varchar(15) COLLATE utf8_lithuanian_ci NOT NULL,
  `password` varchar(200) COLLATE utf8_lithuanian_ci NOT NULL,
  `email` varchar(40) COLLATE utf8_lithuanian_ci NOT NULL,
  `created` datetime NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_lithuanian_ci;

--
-- Sukurta duomenų kopija lentelei `users`
--

INSERT INTO `users` (`id`, `name`, `surname`, `birthday`, `username`, `password`, `email`, `created`, `status`) VALUES
(1, 'Jonas', 'Jonaitis', '2003-11-13', 'jonas', '$2y$10$xu8dSDbe0tpalls/xrCIrewKWBmqS6r4fxiBdEurqTaj4CJzSoBf2', 'zigmantas.rackauskas@gmail.com', '2017-11-22 21:36:42', 1),
(2, 'Jonas', 'Jonaitis', '2018-02-10', 'testas', '$2y$10$.VoDtdWMMvsIVtOiHTmo0.HXswGAL7hfm2.Irxkpcw7JynC5Z3RdC', 'zigmantas.rackauskas@gmail.com', '2018-02-21 08:55:59', 1),
(3, 'testas1', 'testas1', '2018-02-15', 'testas1', '$2y$10$4Dvei0to9JnA10AZv0v2ROmlUckVJXyxWTIbdpnFIOFxkQb4vGzoC', 'zigmantas.rackauskas@gmail.com', '2018-02-21 08:57:46', 1),
(4, 'admin', 'admin', '2018-03-10', 'admin', '$2y$10$PK8HNCDXIvM8okmkdN/0U.DEbIzX6fialkZnwMbyHxO3yEIYd61Lu', 'zigmantas.rackauskas@gmail.com', '2018-03-19 23:24:46', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
