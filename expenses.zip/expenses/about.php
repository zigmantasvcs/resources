<?php require_once("pageparts/top.php"); ?>
<?php require_once("pageparts/nav.php"); ?>
<div class="container">
  <section>
    <div class="row">
      <article class="col s12 m12">
        <div class="box">
          <h5>Apie mus</h5>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>
      </article>
    </div>
  </section>
</div>
<?php require_once("pageparts/footer.php"); ?>
<?php require_once("pageparts/bottom.php"); ?>
