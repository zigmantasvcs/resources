<?php
  namespace calendar\data;

  class Event extends \MyBase{
    public $event;
    public $eventDate;
  }
 ?>
