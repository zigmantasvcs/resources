<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <script src="js/calendar.js"></script>
    <script>
      var menuo = GetMonthNameBox();
      $("body").append(menuo);
    </script>
  </head>
  <body>

  </body>
</html>
